from django.apps import AppConfig


class JournalistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'journalist'
